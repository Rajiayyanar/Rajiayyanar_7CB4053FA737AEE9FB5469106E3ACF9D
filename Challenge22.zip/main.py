class player:
    def play(self):
        print("The Player is playing Cricket")

class batsman(player):
    def play(self):
        print("The Batsman is Batting")

class bowler(batsman):
    def play(self):
        print("The Bowler is Bowling")
    
obj=bowler()
obj.play()
